package com.iam.myapplication.databases;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

public class EtudiantDAO extends DAOBase {
    public SQLiteDatabase sqLiteDatabase;

    public EtudiantDAO(Context pcontext) {
        super(pcontext);
    }

    public void modifierEtudiant(Etudiant etudiant) {
        ContentValues value = new ContentValues();

        value.put(DatabaseIAM.NOM, etudiant.getNom());
        value.put(DatabaseIAM.PRENOM, etudiant.getPrenom());
        value.put(DatabaseIAM.AGE, etudiant.getAge());

        sqLiteDatabase = this.open();

        sqLiteDatabase.update(DatabaseIAM.TableEtudiant, value, DatabaseIAM.ID + "=" + etudiant.getIdEtudiant(), null);
        sqLiteDatabase.close();

    }

    public void ajouterEtudiant(Etudiant etudiant) {
        ContentValues value = new ContentValues();

        value.put(DatabaseIAM.NOM, etudiant.getNom());
        value.put(DatabaseIAM.PRENOM, etudiant.getPrenom());
        value.put(DatabaseIAM.AGE, etudiant.getAge());
        sqLiteDatabase = this.open();
        sqLiteDatabase.insert(DatabaseIAM.TableEtudiant, null, value);
        sqLiteDatabase.close();

    }

    public void supprimerEtudiant(Long idetudiant) {
        sqLiteDatabase = this.open();
        sqLiteDatabase.delete(DatabaseIAM.TableEtudiant, DatabaseIAM.ID + "=" + idetudiant, null);
        sqLiteDatabase.close();


    }

    public List<Etudiant> getAllEtudiants() {
        sqLiteDatabase = this.open();
        Cursor c = sqLiteDatabase.rawQuery("select * from " + DatabaseIAM.TableEtudiant, null);
        List<Etudiant> etudiants = new ArrayList<Etudiant>();
        if (c != null) {
            c.moveToFirst();
            while (c.moveToNext()) {
                Etudiant e = new Etudiant();
                e.setIdEtudiant(Long.parseLong(c.getString(0)));
                e.setNom(c.getString(1));
                e.setPrenom(c.getString(2));
                e.setAge(Integer.parseInt(c.getString(3)));


            }
        }
        sqLiteDatabase.close();
        return etudiants;


    }

   /* public Etudiant selectionnerEtudiant(Long idEtudiant) {
        sqLiteDatabase = this.open();

            Cursor cursor = sqLiteDatabase.query(true, DatabaseIAM.TableEtudiant, new String[]{
                            DatabaseIAM.ID, DatabaseIAM.NOM, DatabaseIAM.PRENOM, DatabaseIAM.AGE},
                    DatabaseIAM.ID + "=?", new String[]{String.valueOf(idEtudiant)}, null, null, null, null);
            if (cursor != null)
                cursor.moveToFirst();
            Etudiant etudiant = new Etudiant(Long.parseLong(cursor.getString(0)), cursor.getString(1), cursor.getString(2), Integer.parseInt(cursor.getString(3)));
            return etudiant;


        }*/

}


