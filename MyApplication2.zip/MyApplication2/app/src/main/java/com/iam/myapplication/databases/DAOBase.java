package com.iam.myapplication.databases;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

import com.iam.myapplication.databases.Etudiant;

public class DAOBase {
    protected SQLiteDatabase sqLiteDatabase;
    protected DatabaseIAM dbIAM;

/*
    public DAOBase(DatabaseIAM dbIAM, SQLiteDatabase sqLiteDatabase) {
        this.dbIAM = dbIAM;
        this.sqLiteDatabase = sqLiteDatabase;

    }
*/
    public DAOBase(Context pcontext){
        this.dbIAM = new DatabaseIAM(pcontext);
    }

    public SQLiteDatabase open(){
        sqLiteDatabase = dbIAM.getReadableDatabase();
        return sqLiteDatabase;

    }

    public void  close(){
        sqLiteDatabase.close();
    }
    public SQLiteDatabase getDatabase(){
        return sqLiteDatabase;

    }

}
