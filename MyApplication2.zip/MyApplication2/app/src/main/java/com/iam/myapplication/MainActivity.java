package com.iam.myapplication;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Camera;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;


import com.iam.myapplication.databases.Etudiant;
import com.iam.myapplication.databases.EtudiantDAO;

import java.io.File;

public class MainActivity extends AppCompatActivity {

    Button btn;
    Button btnphoto;
    ImageView imageViewphoto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final Button button = findViewById(R.id.btn1);
        btnphoto = findViewById(R.id.btnphoto);
        imageViewphoto = findViewById(R.id.imageViewphoto);

        View.OnClickListener listenerphoto = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                takePhoto();
            }
        };
        btnphoto.setOnClickListener(listenerphoto);



        View.OnClickListener listener = new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                try{
                    Etudiant a = new Etudiant(null, "Seck", "Baye ndemba",28 );
                    EtudiantDAO etudiantDAO = new EtudiantDAO(MainActivity.this);
                    etudiantDAO.ajouterEtudiant(a);
                    Toast.makeText(MainActivity.this, "Etudiant enregistré", Toast.LENGTH_SHORT).show();
                   // for (etudiantDAO)
                    Toast.makeText(MainActivity.this, "liste des etudiants :", Toast.LENGTH_LONG).show();


                }catch (Exception e){
                    e.getMessage();
                    System.out.println(e);
                    Toast.makeText(MainActivity.this, "Erreur: " + e, Toast.LENGTH_SHORT).show();

                }
            }
        };
        button.setOnClickListener(listener);
    }

    public void takePhoto (){
        File file = new File (Environment.getExternalStorageDirectory(), "img.jpg");
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        Uri.fromFile(file);
        startActivityForResult(intent,100);

    }

    public void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if (requestCode ==100){
            Bitmap bitmap = (Bitmap) data.getExtras().get(String.valueOf(data));
            this.imageViewphoto.setImageBitmap(bitmap);




        }

    }



}
